document.getElementById("myform").addEventListener("submit", function(e){
  // prevent form submission
  e.preventDefault();

  let email = document.getElementsByName("email")[0].value;
  let password = document.getElementsByName("password")[0].value;
  let username = document.getElementsByName("username")[0].value;


  // send AJAX request
  fetch("/process", {
    method:"POST",
    headers:{
      "Content-Type":"application/json"


    },
    body: JSON.stringify({email:email, password:password, username:username}),
  })
  .then(function(response){
    if(response.ok){

      alert("Data inserted successfully!");
      document.getElementById("email").value = "";
      document.getElementById("password").value = "";
      document.getElementById("username").value = "";
      getData();
    }else{
      alert("Failed to insert data!");
    }
  })
  .catch(function (error) {
    console.error("Error:", error);
    alert("An error occurred!");
  });
    
});










let register_btn = document.querySelector(".Register-btn");
let login_btn = document.querySelector(".Login-btn");
let form = document.querySelector(".Form-box");


register_btn.addEventListener("click", () => {
  form.classList.add("change-form");
});


login_btn.addEventListener("click", () => {
  form.classList.remove("change-form");
});
