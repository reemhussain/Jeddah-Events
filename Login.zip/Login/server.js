// create the server
const express = require("express");
const app = express();
const port = 3000;

//static routing
app.use("/", express.static("./website"));

// HTML routing
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.post("/process", (request, response) => {
    // reading form data
    // POST = request.body.email

    const data = {email: request.body.email, password: request.body.password, username: request.body.username};
    const query = "INSERT INTO user SET ?";
    let msg = {};

    pool.query(query, data, (error, result) => {
        if (error) throw error;
        response.send("Data inserted successfully!");
    });   
});

app.get("/view", (request, response) => {
    const query = "SELECT * FROM user";

    pool.query(query, (error, result) => {
        if (error) throw error;

        response.json(result);
    })
})

// JSON ROUTING
/*app.use(express.json());
app.post("/process", (request, response) => {
    // reading form data
    // POST = request.body.email

    const email = request.body.email;
    const password = request.body.password;
    let msg = {};

    if(email.length > 0 && password.length > 0){
        msg = {status:true,err:""}
       } else {
        msg = {status:false,err:"Kindly complete the form (Name and email are required!)"}
       }
    response.json(msg);

    
});
*/

// server

app.listen(port, () => {
    console.log("Server is running on port " + port);
});


function addUser(email, password, username){
    // connection
    const Mysql = require("mysql2");
    const pool = Mysql.createPool({
        connectionLimit: 10,
        host:"localhost",
        user:"root",
        password:"root",
        port:"3306",
        database:"jeddahevent"
    });

    db.connect(function(err){
        // sql command
        let sql = `INSERT INTO user (email, password, username) VALUES ('${email}', '${password}', '${username}')`;
        db.query(sql, function(err, result){
            if(err) throw err;
            console.log("1 record has been added");
            // close connection
            db.end();
        })
    })
}